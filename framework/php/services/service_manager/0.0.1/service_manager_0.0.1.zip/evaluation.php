<?php

include_once 'index.php';
echo json_encode(ServiceFactory::definition());

?>